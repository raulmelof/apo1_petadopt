package model;

public class Doador {
	private String nomeDoador;
	private String telDoador;
	private String enderecoDoador;
	private String cpfDoador;
	
	public String getNomeDoador() {
		return nomeDoador;
	}
	public void setNomeDoador(String nomeDoador) {
		this.nomeDoador = nomeDoador;
	}
	public String getTelDoador() {
		return telDoador;
	}
	public void setTelDoador(String telDoador) {
		this.telDoador = telDoador;
	}
	public String getEnderecoDoador() {
		return enderecoDoador;
	}
	public void setEnderecoDoador(String enderecoDoador) {
		this.enderecoDoador = enderecoDoador;
	}
	public String getCpfDoador() {
		return cpfDoador;
	}
	public void setCpfDoador(String cpfDoador) {
		this.cpfDoador = cpfDoador;
	}
}
