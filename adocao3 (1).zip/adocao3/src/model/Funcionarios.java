package model;

public class Funcionarios {
	private String nomeFuncionario;
	private Integer idFuncionario;
	private	String depFuncionario;
	
	public String getNomeFuncionario() {
		return nomeFuncionario;
	}
	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}
	public Integer getIdFuncionario() {
		return idFuncionario;
	}
	public void setIdFuncionario(Integer idFuncionario) {
		this.idFuncionario = idFuncionario;
	}
	public String getDepFuncionario() {
		return depFuncionario;
	}
	public void setDepFuncionario(String depFuncionario) {
		this.depFuncionario = depFuncionario;
	}
}
