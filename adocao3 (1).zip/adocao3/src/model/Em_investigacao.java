package model;

public class Em_investigacao extends Cliente {

}
