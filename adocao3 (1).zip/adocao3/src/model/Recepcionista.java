package model;

public class Recepcionista extends Funcionarios {

}
